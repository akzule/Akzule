================================================================================
MetodosObject:
  @toString(); // devuelve un texto.
    public String toString(); // al colocar el objeto en un parametro muchos de estos ejecutan el metodo toString del objeto y esto devuelve un texto para cada objeto, por ejemplo: System.out.println(objeto);
    
  @wait(); // pone el hilo actual a la espera.
    public void wait(); // si un metodo esta sincronizado con la palabra reservada sinchronized se puede utilizar para pausar un hilo y luego reanudarlo.
    
  @notifyAll(); // reanuda todos los hilo pausados y sincronizados.
    public void notifyAll(); // reanuda los hilos sincronizados con la palabra sinchronized en el metodo que utiliza este metodo y el metodo wait.
  
================================================================================