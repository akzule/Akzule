# Información:
### Sistema y lenguaje
* java es un lenguaje de alto nivel, concurrente (multi hilo) orientado a objetos.
	Los lenguajes de alto nivel son los más alejados a el código de tipo maquina, java estaría en un nivel 3 de jerarquía de este tipo.

* el código fuente se compila a byteCodes y la JVM (máquina virtual de java) interpreta los byteCodes a programación que la plataforma entienda. El proceso es el siguiente: editar, compilar, cargar clases, verificar y ejecutar.
	Un fichero fuente se refiere al archivo .java en donde va la ejecución del programa con una o más clases.
	
* case sensitive se refiere a que el lenguaje es sensible a las mayúsculas y minúsculas.

* la JRE (entorno de ejecución java) es necesario para ejecutar un programa en java (JRE=JVM).

* la JVM (java virtual machine) se refiere a la máquina virtual de java (JVM=JRE).

* el JDK (java development kit) son programas java que pueden servir como herramientas para la compilación, ejecución y otros.

* Java ME (Java Platform, Micro Edition) o J2ME orientada a entornos de limitados recursos, como teléfonos móviles, PDAs (Personal Digital Assistant), etc.

* Java SE (Java Platform, Standard Edition) o J2SE para entornos de gama media y estaciones de trabajo. Aquí se sitúa al usuario medio en un PC de escritorio.

* Java EE (Java Platform, Enterprise Edition) o J2EE orientada a entornos distribuidos empresariales o de Internet.

* java web start es la herramienta que ejecuta programas desde un servidor remoto.

* todo lo referente al api es controlado desde la compañía Sun Microsystems y otras entidades o personas mediante el programa JCP (Java Community Process).

* enlazado dinámico hace referencia a que la JVM selecciona automáticamente el método, constructor o variable de la subclase o superclase dependiendo del contexto.

* el garbage recollector es la herramienta que utiliza java para liberar espacio de variables que no tengan referencia o sean nulas.

* un layout o disposición sirve para definir el orden o forma de ordenar un componente.

* un inicializador es una clase de método sin parámetros y se ejecuta antes del método, se declara como: static{código} o solo {código} y va dentro de la clase objeto.

* modularizacion se refiere a dividir un programa en múltiples clases, partes o módulos, etc.

* una declaración implícita es la declaración e iniciación de un array, vector o arreglo y variable.

* una bifurcación es un condicional.

* un condicional, bucle, clase, etc. anidados son los mismos dentro de otro del mismo tipo correspondientemente, por ejemplo: un condicional if anidado seria if(condición){if(condición){código}};

* una clase interna es una clase anidada que básicamente hereda de la clase externa y puede tener un modificador de acceso cualquiera, la clase externa puede instanciar a la clase interna como objeto y acceder perfectamente a campos de clase privados de esta clase interna, la clase interna no puede contener en su interior variables o métodos estáticos.

* una clase interna local es una clase dentro de un método, no puede llevar modificadores de acceso y solo el método es accesible a ella, si se desea utilizar un parámetro del método se debe definir ese parámetro como constante con la palabra reservada final, el método no puede tomar como retorno esta clase ya que ella existe cuando el flujo de ejecución la alcanza al accionar el método.

* las clases adaptadoras son las que implementan una interfaz para poder heredar de ella y evitar tener que sobrescribir todos los métodos de esa interfaz en una clase.

* una clase interna anónima es instanciar una clase y añadir llaves además del constructor, en donde se sobrescribirán métodos y agregara código, por ejemplo: new Clase(){}

* la refundición o casting es el cambiar el tipo de un valor a otro tomando en cuenta la lógica, por ejemplo: byte variable = (byte)variable; esto puede causar en múltiples casos perdida de datos.

* una instancia de objeto o ejemplar de objeto es el crear un objeto que se podrá almacenar en variables, arrays o parámetros tomando en cuenta el polimorfismo.

* atributo es una especie de propiedad.

* método es una especie de comportamiento.

* nomenclatura del punto se refiere a la forma de trabajar con los objetos, por ejemplo: objeto.atributo; objeto.atributo=valor; objeto.metodo();

* encapsulación hace referencia a la privacidad de una variable, constante, método, constructor o clase etc.

* getter y setter se refiere a los métodos que devuelven info y a los que modifican info correspondientemente, por ejemplo: getVariable() y setVariable();

* un campo de clase es la variable declarada en una clase que se duplicara para cada objeto al igual que están los campos de clase estáticos.

* la sobrecarga de métodos y constructores es tener múltiples métodos o constructores con el mismo nombre, pero una forma diferente de trabajar en los parámetros y código.

* polimorfismo o principios de la sustitución se refiere a colocar una subclase en donde se espera una superclase, por ejemplo: Padre[] matriz={new Hijo, new Padre};

* una excepción es un tipo error que va de parte del programador y usuario más que del hardware.

* una excepción comprobada es la que hereda de IOException y una excepción no comprobada es la que hereda de RuntimeException.

* las excepciones también son clases así que se importan.

* el debugger de un entorno de desarrollo puede venir en app o integrado y es útil para testear cada valor y posición del flujo de ejecución pausándolo, avanzándolo o retrocediendo y manipulando manualmente el valor de cada espacio.

* un thread es un hilo de ejecución, puede haber múltiples hilos simultáneamente.

* la muerte de un hilo se refiere a que ha terminado su ejecución.

* las colecciones sirven para almacenar objetos con muchas posibilidades, entre menos posibilidades mejor rendimiento, todas las interfaces y clases que implementen la interfaz Colection son colecciones.

* una clase genérica hace referencia a utilizar un argumento en una clase, esto indicado por corchetes angulares luego del nombre de una clase para especificar que dicho identificador en su interior puede ser una clase cualquiera, al utilizar la clase genérica desde el exterior se deberá especificar dicha clase con los mismos corchetes, por ejemplo: Class<String> objeto=new Class<String>(); en donde se crea el objeto de la clase genérica, y public class Class<T>{} en donde T es la clase cualquiera con la que se trabajara dentro de la clase.

* la programación genérica hace referencia a el uso de clases genéricas y su adaptación.

* un flujo de datos o stream es la conexión que hace un método para tener leer y escribir datos en un archivo externo.

* un buffer o filtro es la memoria intermedia al leer o escribir datos, esto permite que cualquier cambio inesperado en el archivo o la conexión no cause datos en la lectura o escritura de datos.

* la serialización hace referencia a un objeto capaz de convertirse y desconvertirse de a datos o viceversa, a estos objetos se les llama serializable e implementan la interfaz serializable que esta vacía.

* un SHA es un identificador de objeto.

* se puede empaquetar un proyecto con un manifiesto y bytecodes en extensión jar, para ejecutarse desde su navegador o en múltiples plataformas, si es un jar ejecutable.

* se puede firmar un archivo jar para poder acceder a permisos como acceder a archivos, Para esto deberemos crear una firma con la aplicación Keytool y firmar el jar con la aplicación Jarsigned que están dentro del JDK y se deberá usar la consola o símbolo del sistema para esto.

* se puede ejecutar un programa desde un servidor remoto subiendo un jar junto a un archivo XML con extensión .JNLP, este archivo especificara todo, desde la clase principal hasta la versión del programa (nombre, titulo, versión mínima de la máquina virtual, etc).
	Al utilizar el procedimiento JNLP se debe abrir el archivo desde un navegador para que este de paso a ejecutar el programa del jar con java web start.
	

### Clases
* el paquete de clases usado por defecto es java.lang y el directorio actual del proyecto el cual es normalmente src.

* si se va a utilizar una clase que no esté en el paquete por defecto se deberá importar la clase o el mismo paquete.

* al crear un paquete se debe escribir en minúsculas él y sus sub-paquetes.

* todas las clases heredan de la clase Object del paquete java.lang, aunque pertenezcan a otro paquete, esto sucede automáticamente ya que nuestras clases son una X clase y las X clase heredan de la clase object, con X clase me refiero a la clase Class<?>.

* la clase principal debe ser publica e iniciar su nombre por una letra mayúscula y separar palabras con barra baja o letra mayúscula, por ejemplo: palabraUno o palabra_uno. No debe ser el nombre de una palabra reservada.

* el nombre de la clase principal debe llamarse como el mismo fichero en donde se programa la clase.

* si hay múltiples clases en un fichero solo la principal debe tener un modificador de acceso que actuara sobre todas las clases.

* para instanciar una clase interna desde una externa incluso si la clase externa es la clase principal entonces se deberá declarar esta clase interna como estática.

* para referirse a un campo de clase como por ejemplo una variable o una clase interna durante un flujo de ejecución se debe utilizar la palabra reservada this para no hacer referencia al flujo global, por ejemplo: this.variable;

* si un método se declara como estático en la clase del objeto no podrá manipular campos de clase a menos que sean estáticos. Un método o variable estática se representa como Clase.Metodo;

* los enumerados se crean dentro de la clase pero fuera de cualquier método definidos por la palabra reservada enum.

* si una clase tiene un método abstracto la clase deberá ser abstracta.

* si se crea un método en una subclase igual a él método de una superclase se sobrescribirá el código a ejecutar de ese método.

* una interfaz es abstracta y solo contiene métodos públicos y abstractos además de constantes, estos se definen, aunque no se coloquen manualmente las palabras reservadas public, abstract y final. Una interfaz no puede ser instanciada de la forma convencional de new Interfaz(); se deberá instanciar de forma que sobrescriba sus métodos, por ejemplo: new Interaz(){metodos};

* las interfaces no pueden implementar interfaces y no pueden heredar de una clase, pero si de una interfaz.

* las clases no pueden heredar de interfaces.


### Código
* para comentar una línea se utiliza la doble barra	// comentario.

* y para múltiples líneas la barra asterisco y asterisco barra	/* comentario */.

* la ejecución de un programa inicia desde el método main que se escribe como: public static void main(String[]args){}

* se debe colocar punto y coma al final de cada sentencia o instrucción, por ejemplo: int variable;

* las variables o las constantes debe iniciar su nombre por una letra minúscula y separar palabras con barra baja o letra mayúscula, por ejemplo: palabraUno o palabra_uno. No debe ser el nombre de una palabra reservada.

* por convención se usa la variable inicializadora i, j o z en el inicio de un bucle for.

* puedes instanciar objetos directamente en parámetros, por ejemplo: metodo(new Object());

* el nombre de un parámetro tipo evento se denota como "e" por convención.

* al definir un evento podemos definir un objeto por medio de una interfaz en dónde uno de sus métodos ejecutará el código el cuál recibira un objeto tipo event para hacer las consultas respecto al objeto que activo metodo, por ejemplo referencia al estado del objeto o con que clic se presionó el objeto.

* un evento se compone de: fuente de evento (para definir el objeto que acciona el evento de la interfaz), oyente (definir el objeto a el que afectara el método de la interfaz) y evento (para la clase que implementa la interfaz).

* la mejor forma de crear un thread es crear un objeto de tipo thread y pasarle al constructor un objeto que implemente la interfaz Runnable, luego para accionar el thread se utiliza el método start() que hará que se ejecute el método run dentro de la clase con la interfaz Runnable.

* los threads o hilos funcionan igual que un campo de clase actualmente para mejor control desde distintos puntos individuales.

* los 4 estados de un thread o hilo son: nuevo, ejecutable, bloqueado y muerto, ocasionados al crear un objeto del mismo. Poder usar el método start, dormirlo o pararlo y terminar su ejecución de manera natural o manual.

* un hilo se puede sincronizar con el método join del hilo actual para ejecutar solo 1 hilo a la vez hasta que termine su ejecución o con la clase ReentrantLock para bloquear el código de un hilo hasta que termine su ejecución, este último puede ser desbloqueado con el método unlock o con un return sin valor y bloqueado con el método lock.

* si se utiliza el método newCondition de la clase ReentrantLock devolverá un objeto de tipo Condition que servirá para poder poner un hilo a la espera para que no muera y se pueda reanudar desde otro hilo luego que ese otro hilo haga cambios (y más).
	* El primer método await() de la interfaz Condition pone el hilo a la espera y desincroniza los hilos que se sincronizaban por medio del método lock() de la clase ReentrantLock, este método debe estar dentro de un while que actuara como condición para colocar a la espera el hilo y el hilo debe estar bloqueado con el método lock() de la clase ReentrantLock, el segundo método signalAll() que reanuda todos los hilos pausados, este método se debe usar también en un hilo bloqueado pero por el método lock() de la clase ReentrantLock.
	
	* Aparte de la interfaz Condition que devuelve el método newCondition de la clase ReentrantLook podemos hacer algo similar colocando la palabra reservada synchronized en el método después del modificador de acceso que actuara como la condición y los métodos wait() y notifyAll() que remplazarían a los métodos await() y signalAll() correspondientemente, por ser de la clase Object se utilizan directamente pero lo negativo de usar este método de sincronización condicional es que solo se puede utilizar una condición para pausar el hilo.


### POO
* si un objeto que hereda de una clase está dentro de un array que admite objetos de ésta clase entonces no se podrán usar los métodos del objeto qué no esten en la clase de la cual es el array (superclase o clase padre) a menos que se haga una refundición.
	Para almacenarse de nuevo en una variable de su tipo se hace una refundición, por ejemplo: Object objeto=(Object)arrayPadre[0];

* es recomendable en algunos casos utilizar métodos desde el constructor para definir directamente valores cuando nuestra clase objeto hereda de otra que usa métodos setters para definir parámetros, los métodos se accionaran desde la clase padre y los resultados se reflejaran a la subclase.

* se puede realizar el polimorfismo o regla de sustitución si una clase objeto implementa una interfaz o hereda de una clase.
	Si un parámetro requiere una interfaz o clase abstracta deberemos crear nuestra clase que implemente o herede de esa interfaz o clase respectivamente.


### Programación genérica
* la programación genérica ayuda a la reutilización de código, mayor sencilles del código y mejor control de errores, estos se harán en tiempo de compilación y no de ejecución lo que mejora el debug.

* el identificador entre corchetes de una clase genérica se puede utilizar en cualquier parte como si fuera una clase.

* por convención los identificadores de una clase genérica se denotan E, T, U o K.

* también puede haber métodos genéricos independientes de la clase, así que la clase no tiene que ser genérica, esto se especifica antes del tipo de retorno del método, por ejemplo: public <T> void metodo(){}

* si el identificador de una clase o método genérico debe implementar o heredar de una clase se especifica con la palabra extends en los corchetes angulares, por ejemplo: public class Clase<T extends Comparable>{}

* entre las interfaces genéricas más utilizadas esta la interfaz comparable con el método compareTo.


### Interfaz
* la layout o disposición por defecto es flowLayout con una gravedad superior central para los contenedores como JPanel o JFrame etc.

* a todos los componentes se les puede poner a la escucha de un evento o agregar un menú emergente en el que se agregaran los items y menús.

* un menú grafico utiliza 3 clases para la barra, los menús y los ítems. Un menú puede ir dentro de otro y los menús contienen ítems, estos ítems pueden ser normales o seleccionables y para su funcionamiento se ponen a la escucha de un evento.


### Applet
* un applet inicia heredando de la clase JApplet que es un tipo lamina, la ejecución del código inicia desde método init. Por ejemplo: public void init(){}

* para agregar un applet dentro del archivo HTML se usa la etiqueta applet dentro de la etiqueta body, por ejemplo: <html><body><applet code="rutaArchivo.class" width="200" height="200"> </applet></body></html>

* actualmente las applets están obsoletas, la clase JApplet esta @deprecated y ya removieron la etiqueta applet del navegador por problemas de seguridad ya que los applets eran usados por hackers.

* un applet puede ejecutar una ventana emergente como un panel.

* se le puede pasar parámetros al applet desde el archivo html colocando la etiqueta <param> dentro de la etiqueta applet, por ejemplo: <param name="variable" value="texto"> y llamándola desde java con el método getParameter("variable");

* para ejecutar un applet cuando este empaquetado en un archivo jar se deben modificar de la siguiente manera la etiqueta applet: <applet code="rutaArchivo.class" archive="rutaArchivo.jar" width="200" height="200"></applet>


### Archivos
* si leemos un archivo con el método read de la clase InputStreamReader podremos hacer un casting hacia la clase char para ver el carácter de ese byte, es un método acumulativo así que por cada ves que se use avanzara 1 carácter.

* para leer o escribir un objeto el mismo debe ser serializable.

* al leer un objeto se debe almacenar en una variable de ese objeto o array (si es un array) y luego hacer casting.

* cada objeto que escribamos tendrá un SHA(serialVersionUID) que cambiará dependiendo de cómo este la clase, campos de clase, métodos, etc. 

* no podremos leer objetos con distintos SHA a la clase que utiliza el objeto a menos que especifiquemos el SHA manualmente en la clase creando una constante estática de tipo long llamada serialVersionUID y la declaremos con un número que será el SHA.

* la clase con más opciones con respecto a archivos y directorios es la clase File que puede hacer verificaciones, leer y escribir en archivos o crear y eliminar archivos y ficheros.

* siempre que se habrá una un stream se deberá cerrarse cuando termine la totalidad de su uso, normalmente con el método close().


### Errores
* los errores se dividen en los de tiempo de compilación(sintaxis) y los de tiempo de ejecución(lógica). Hay excepciones de tipo IOException y RuntimeException que heredan de la clase Exception y que a su vez junto con los errores heredan de la clase Throwable.

* para crear un método propio se hace creando una clase que herede de la clase Exception, IOException o RuntimeException y se crea un constructor que invoque al de la clase padre, es útil crear otro método que reciba un string para darle al de la clase padre el parámetro, esto sirve para más información en la excepción.

* para conseguir información del error desde un catch se usa por ejemplo el método printStackTrace(); en el objeto excepción, por convencionalidad se nombra como "e".

* se puede mover el cursor de debuggin en secuencia con el botón stev over, o pasar de un punto de interrupción a otro con el botón run, y acceder al flujo de ejecución de un método con el botón step in, para salir del mismo se presiona el botón step out.


### Fundamentos
* en un condicional o bucle donde haiga llaves y en su interior código puede ser sustituido por una simple sentencia.

* si se crea un método, clase, enumerado o campo de clase dentro de la clase puede tener modificador de acceso, si se crea una clase o campo de clase dentro de un método o control de flujo que no sea el principal no tendrá modificador de acceso y será local.

* para acceder a un método, clase, enumerado o campo de clase se toma en cuenta el modificador de acceso y la nomenclatura del punto referente a la clase, si la clase o campo de clase es local no se podrá acceder directamente a través de su nombre.

* cualquier cosa que declaremos puede tener una palabra reservada correspondiente solo si la cumple la lógica de funcionar, por ejemplo, la palabra static para una clase o un modificador de acceso para un enumerado.

* se pueden colocar etiquetas antes de un bucle para manipular el flujo de ejecución de estos bucles con las palabras reservadas break y continue, por ejemplo: etiqueta: while(){}

* al heredar o implementar una interfaz genérica correspondientemente se debe identificar la clase de ese identificador ya sea la subclase genérica o no.

* cuando un parámetro obtiene un objeto o array etc. puede tomar esos objetos y editarlos desde el método de ese parámetro, aunque sea la clase de un objeto.


### Curiosidades
* si se crea un método que como parámetro trae un "tipo" seguido de tres puntos y luego un nombre entonces se estará exigiendo un array de parámetro, por ejemplo: public void metodo(String...nombre){}

* después de que un método haga un return finaliza el método.

