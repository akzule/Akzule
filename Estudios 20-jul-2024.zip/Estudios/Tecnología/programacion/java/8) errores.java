================================================================================
Errores:
// solo las excepciones comprobadas son las que obligan a capturar la excepcion.
  Jerarquia:
  TiempoDeCompilacion(sintaxis) // se producen al escribir mal una instruccion e intentar compilar.
  TiempoDeEjecucion(logica) // se produce al tener mal hecha la logica del programa.
    Throwable // la clase de donde heredan excepciones y errores.
      Error // es una clase para lanzar un error del sistema mayormente, como por ejemplo por falta de ram etc.
      Exception // una clase para lanzar errores de tipo excepciones.
        IOException // (excepcion comprobada) una clase que lanza un error al no encontrar un archivo en una ruta especificada.
        RuntimeException // (excepcion no comprobada) una clase que lanza un error al hacer algo no logico en un programa como imprimir la longitud de un array nulo.
  
  
  CapturarUnaException(try catch):
  try{posibleExcepcion}catch(Exception e){codigoDeRespaldo}finally{codigoConstante} // si el codigo del try lanza una exception identificada en el catch ejecutara el catch, pueden aver multiples catch y siempre se ejecutara el finally halla o no alla un error.
  try{codigo} // identifica un error.
  catch(Exception e){codigo} // captura un tipo de excepcion especifica y la almacena para identificarla y accionar el codigo.
  finally{codigo}  // ignora la excepcion si lo hay y ejecuta el codigo.
  
  
  MarcarUnaExcepcion:
  public void metodo throws IOException, RuntimeException(){} // indica que excepciones devuelve un metodo.
  throw new IOException(); // genera una excepcion del tipo IOException que es una clase.

================================================================================