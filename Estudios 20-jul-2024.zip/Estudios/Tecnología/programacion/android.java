================================================================================
Informacion:
  Tips:
  0) 
  
  Lenguaje:
  0) 
  
  Fundamentos:
  0) 
  
  Curiosidades:
  0) 
  
================================================================================
PalabrasReservadas:
abstract // 

================================================================================
Ejemplos:
  Clases:
    package paquete.subpaquete; // declara el paquete actual de la clase, por ejemplo: package paquete.subPaquete;
    
    
  Otros:
    final int CONSTANTE; // declara una constante, por ejemplo: final tipo NOMBRE;
  
================================================================================