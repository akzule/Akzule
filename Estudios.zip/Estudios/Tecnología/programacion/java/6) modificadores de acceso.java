================================================================================
ModificadoresDeAcceso:
// se pueden colocar en variables, metodos, enumerados, clases e interfaces.
public // se puede acceder desde: clase(si) paquete(si) claseExtendida(si) clasesDeCualquierLugar(si)
protected // se puede acceder desde: clase(si) paquete(si) claseExtendida(si) clasesDeCualquierLugar(no)
private // se puede acceder desde: clase(si) paquete(no) claseExtendida(no) clasesDeCualquierLugar(no)
PorDefecto // se puede acceder desde: clase(si) paquete(si) claseExtendida(no) clasesDeCualquierLugar(no)

================================================================================