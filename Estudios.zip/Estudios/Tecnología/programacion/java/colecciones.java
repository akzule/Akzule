================================================================================
Colecciones:
// las interfaces son las que contienen un @ y las otras serian las clases.
  Jeraraquia:
  
  
    @Colection
      @Set
      /*
        ventajas:
        -no permiten elementos duplicados.
        -uso sencillo del metodo add que ademas asegura no elementos duplicados.
        
        inconvenientes:
        -no tiene acceso aleatorio.
        -poca eficiencia a la hora de ordenar elementos(y no siempre se puede).
      */
        HashSet
          // rapida.
          // no duplicados.
          // no ordenacion.
          // no acceso aleatorio.
        LinkedHashSet
          // ordenacion por entrada.
          // eficiente al acceder.
          // no eficiente al agregar.
        TreeSet
          // es ordenado.
          // poco eficiente.
        EnumSet
          // la mejor para tipos enumerados.
        CopyOnWriteArraySet
          // especifico concurrencia.
          // eficiente lectura.
          // poca eficiente escritura.
          // poco eficiente al eliminar.
        ConcurrentSkipListSet
          // especifico concurrencia.
          // admite ordenacion.
          // con muchos elementos no es suficiente.
        @SortedSet
        
      ?????????????????????????????????
        
      @List
      /*
        ventajas:
        -acceso aleatorio.
        -estan ordenadas(Colection.sort()).
        -a�adir / eliminar sin restriccion.
        -ListIterator modifica en cualquier direccion.
        -sintaxis similar a Arrays.
        
        inconvenientes:
        -bajo rendimiento en operaciones concretas que se resolverian mejor con otras interfaces.
      */
        ArrayList 
          // muy rapido accediendo a elementos.
          // se adapta a un gran numero de escenarios.
        LinkedList 
          // listas enlazadas.
          // gran eficiencia agregando y eliminando elementos.
        Vector 
          // considerada como coleccion obsoleta.
          // utilizada unicamente en operaciones de concurrencia.
        CopyOnWriteArrayList 
          // utilizada en programas concurrentes.
          // eficiente en operaciones de lectura pero muy poco eficiente en operaciones de escritura.
          
      ?????????????????????????????????
          
      @Queue
      /*
        ventajas:
        -muy rapido al acceder al primer y ultimo elemento.
        -permite crear colas de elementos muy eficientes. (LIFO/FIFO).
        
        inconvenientes:
        -acceso lento a los elementos intermedio.
      */
      ArrayDeque
        // gran eficiencia.
        // la mas utilizada.
      LinkedBlockingDeque
        // utilizado en programacion concurrente.
      LinkedList
        // rendimiento inferior al ArrayDeque.
      PriorityQueue
        // para utilizar un Comparator.
        // el primer elemento dependera de la propiedad elegida.
      PriorityBlockingQueue
       // igual que el anterior pero mas eficiente en programacion concurrente.
      
      ?????????????????????????????????
      
    @Map
    /*
        ventajas:
        -asociacion clave->valor.
        -no claves iguales.
        
        inconvenientes:
        -poca eficiencia comparado con las demas colecciones.
      */
      HashMap
        // no ordenacion.
        // eficiencia.
      LinkedHashMap
        // ordenado por insercion.
        // permite ordenacion por uso.
        // eficiente lectura.
        // poca eficiente escritura.
      TreeMap
        // ordenado por clave.
        // poco eficiente en todas sus operaciones.
      EnumMap
        // permite enum como claves.
        // muy eficiente.
      WeakHashMap
        // utilizado para crear elementos que vaya borrando el sistema si no se utiliza.
        // muy poco eficiente.
      HashTable
        // considerado obsoleto.
        // utilizado en operaciones de concurrencia.
      ConcurrentHashMap
        // utilizado en concurrencia.
        // no permite nulos.
      @SortedMap

================================================================================