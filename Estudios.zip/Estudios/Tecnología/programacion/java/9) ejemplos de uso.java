================================================================================
EjemplosDeUso:
variable, constante, matriz u objeto(y otros):
  Variables:
    int variable; // declara una variable, por ejemplo: tipo nombre;
    variable = 0; // inicia una variable, por ejemplo: nombre = valor;
    int variable = 0; // declara e inicia una variable, por ejemplo: tipo nombre = valor;
  
    int variable, variable2; // declara multiples variables de un tipo, por ejemplo: tipo nombre, nombre2;
    int variable = 0, variable2 = 0; // declara e inicia multiples variables de un tipo, por ejemplo: tipo nombre = valor, nombre2 = valor;
  
  
  Matrices:
    Declaracion:
    int[] matriz; // declara una matriz, por ejemplo: tipo[] nombre;
    int matriz[]; // declara una matriz, por ejemplo: tipo nombre[]; el "[]" puede ir antes o despues del nombre.
    
    int[][] matriz; // declara una matriz bidimensional, por ejemplo: tipo[][] nombre; un "[]" por cada dimension, el desplazamiento de los "[]" van delante o detras del nombre y las cantidades en un lado u otro no son importantes pero la libertad de hacer esto es recomendable solo si se declara e inicia directamente el array.
    
    
    Iniciacion:
    matriz[2] = 24; // inicia una matriz con un numero entero 24 en el indice 2 (inicia desde el indice 0), por ejemplo: nombre[indice] = valor;
    matriz = new int[]{1,2,3,4}; // inicia una matriz con un indice de 4 y sus valores correspondientes, por ejemplo: nombre = new tipo[]{valor, valor, valor};
    matriz = new int[5]; // inicia una matriz con un indice de 5, por ejemplo: nombre = new tipo[indices];
    
    matriz[2][3] = 27; // inicia una matriz bidimensional con un numero entero 27 en el indice (2,3) (inicia desde el indice 0), por ejemplo: nombre[indice1][indice2] = valor;
    matriz = new int[][]{{2,4}, {5,8}}; // inicia una matriz bidimensional con un indice de (2, 2) y sus valores correspondientes, por ejemplo: nombre = new tipo[][]{{valor, valor}, {valor, valor}};
    matriz = new int[1][2]; // inicia una matriz bidimensional con dindice indice (1,2), por ejemplo: nombre = new tipo[indices1][indices2];
    
    
    DeclaracionEIniciacion:
    int[] matriz = {24, 7, 8}; // declara e inicia una matriz con un indice de 3 y sus valores correspondientes, por ejemplo: tipo[] nombre = {valor, valor, valor}; para 3 indices.
    int[] matriz = new int[]{24, 7, 8}; // declara e inicia una matriz con un indice de 3 y sus valores correspondientes, por ejemplo: tipo[] nombre = new tipo[]{valor, valor, valor}; para 3 indices.
    int[] matriz = new int[5]; // declara e inicia una matriz con un indice de 5, por ejemplo: tipo[] nombre = new tipo[indices];
    
    int[][] matriz = {{4, 7}, {9, 0}}; // declara e inicia una matriz bidimensional con los valores dados, por ejemplo: tipo[][] nombre = {{valor, valor}, {valor, valor}}; cada llaves para cada dimension y cada valor para cada indice de la correspondiente dimension en ascendente.
    int[][] matriz = new int[][]{{4, 7}, {9, 0}}; // declara e inicia una matriz bidimensional con los valores dados, por ejemplo: tipo[][] nombre = new tipo[][]{{valor, valor}, {valor, valor}}; cada llaves para cada dimension y cada valor para cada indice de la correspondiente dimension en ascendente.
    int[][] matriz = new int[2][3]; // declara e inicia una matriz bidimensional con dos dos dimensiones con indices2 y 3 que dan un espacio total de 6 casillas, por ejemplo: tipo[][] nombre = new tipo[indices1][indices2];
    
    
    DeclaracioneEIniciacione Multiple:
    int[] matriz, matriz2, matriz3 // declara multiples matrices, por ejemplo: tipo[] nombre, nombre2;
    int[] matriz = new int[2], matriz2 = new int[]{2, 5, 8}, matriz3 = {2, 5, 8}; // declara e inicia multiples matrices, por ejemplo: tipo[] nombre = new tipo[indices], nombre2 = new int[]{valor, valor, valor}, nombre3 = {valor, valor, valor}; las tres formas de iniciar una matriz es valida independientemente.
      
    int[][] matriz, matriz2, matriz3; // declaracio multiples matrices bidimensionales, por ejemplo: tipo[][] nombre, nombre2;
    int[][] matriz = new int[2][3], matriz2 = new int[]{{19, 919, 1}, {1, 9}}, matriz3 = {{19, 919, 1}, {1, 9}}; // declara e inicia multiples matrices bidimensionales, por ejemplo: tipo[][] nombre = new tipo[indices][indices], nombre2 = new int[][]{{valor, valor},{valor}}, nombre3 = {{valor, valor}, {valor}}; las tres formas de iniciar una matriz es valida independientemente.
    
    
    Otros:
    matriz.lenght // Devuelve la longitud de esta matriz, por ejemplo: nombre.lenth
  
  
  Objetos:
    EnLaClaseObjeto:
    { codigo } // esto declara un inicializador que se ejecutara antes que todo al crear un objeto.
    static{ codigo } // esto declara un inicializador estatico que se ejecutara en un ambito estatico asi que no podra modificar campos de clase que no sean eataticos, se ejecutara cuando se use un campo estatico o se cree un objeto.
    public constructor(){} // crea un constructor dentro de una clase que debe llamarse como la clase y acciona lo que pueda aver en su interior, por ejemplo: public nombreClase( parametros ){ codigo }
    public constructor(int a, int b){} // crea un constructor dentro de una clase que debe llamarse como la clase, que pide parametros y acciona lo que pueda aver en su interior, por ejemplo: public nombreClase( parametros ){ codigo }
    public int metodoGetter(){return 0;} // crea un metodo getter dentro de la clase, devuelve un valor definido dependiendo de como queramos devolver y filtrar los parametros, el codigo que pongamos debe ir antes del return, por ejemplo: public tipo nombre( parametros ){ codigo return valor; }
    public void metodoSetter(){} // crea un metodo setter dentro de la clase que acciona las lineas de codigo dependiendo de los parametros y no devuelve nada, por ejemplo: public void nombre( parametros ){ codigo }
    
    public abstract class Clase{} // declara una clase abstracta, por ejemplo: public abstract class Nombre{}
    public abstract int metodo(); // declara un metodo getter abstracto, tendra que sobreescribirse en otras clases que hereden de esta y la clase de este metodo tendra que ser abstracta, por ejemplo: public abstract tipo nombre( parametros );
    public abstract void metodo(); // declara un metodo setter abstracto, tendra que sobreescribirse en otras clases que hereden de esta y la clase de este metodo tendra que ser abstracta, por ejemplo: public abstract void nombre( parametros );
    public void finalize() throws Throwable{super.finalize();} // declara un metodo finalizador vacio para liberar espacio con ayuda del garbage recollector, esto se puede impulsar si utilizas los metodos System.gc(); y System.runFinalization(); para hacer sugerencia al garbage recollector que inicie su trabajo y a el metodo runFinalization lo mismo.
    
    this.variable; // usa el valor de un campo de clase haciendo referencia a la clase y no al parametro o flujo de ejecucion actual, por ejemplo: this.nombreCampoDeClase;
    this.variable = valor; // inicia un campo de clase haciendo referencia a la clase y no al parametro o flujo de ejecucion actual, por ejemplo: this.nombreCampoDeClase = valor;
    this( paremetros ); // inicia un constructor haciendo referencia a la clase, por ejemplo: this.nombreConstructor( parametros );
    this.metodo( parametros ); // ejecuta el metodo haciendo referencia a la clase y devuelve un valor si el metodo es getter, esto es util para la sobrecarga de metodos y se utiliza desde un metodo normalmente, por ejemplo: this.nombreMetodo( parametros );
    super.variable; // usa el valor de un campo de clase haciendo referencia a la superclase y no al parametro o flujo de ejecucion actual, por ejemplo: super.nombreCampoDeClase;
    super.variable = valor; // inicia un campo de clase haciendo referencia a la super clase y no al parametro, por ejemplo: super.nombreCampoDeClase = valor;
    super( paremetros ); // inicia un constructor haciendo referencia a la superclase, por ejemplo: super.nombreConstructor( parametros );
    super.metodo( parametros ); // ejecuta el metodo haciendo referencia a la superclase y devuelve un valor si el metodo es getter, esto es util para la sobreescritura de metodos y se utiliza desde un metodo normalmente, por ejemplo: super.nombreMetodo( parametros );
    this // hace referencia a una clase objeto actual desde un metodo o constructor, por ejemplo: metodo(this);
    Clase.this // hace referencia a una clase objeto actual desde una clase interna o local, por ejemplo: metodo(Clase.this);
    
    enum Talla{PEQUE, MEDIANA, GRANDE}; // declara un enumerado, por ejemplo: enum Nombre{NOMBRE, NOMBRE, NOMBRE}
    enum Talla{PEQUE("P"), MEDIANA("M"), GRANDE("G"); private String abreviatura; private Talla(String a){abreviatura=a;} public String dameAbreviatura(){return abreviatura;}} // declara un enumerado con constructores, variables y metodos, por ejemplo: enum Nombre{NOMBRE( parametros ), NOMBRE( parametros ), NOMBRE( parametros ); codigo}
    
    
    EnElArchivoFuente:
    Clase.atributo; // usa un campo de clase estatico, por ejemplo: Clase.nombreCampoDeClase;
    Clase.atributo = valor; // cambia el valor de un campo de clase estatico, por ejemplo: Clase.nombreCampoDeClase = valor;
    Clase.metodo(); // usa un metodo estatico, por ejemplo: Clase.nombreMetodo( parametros );
    
    Clase variable; // declara una variable de un tipo Clase, por ejemplo: Clase nombre;
    new Clase(); // instancia una clase (crea un objeto del tipo de esa clase), por ejemplo: new Clase( parametros )
    new Interfaz(){public void metodo(){}} // declara la instancia de una clase o interfaz interna anonima, lo que crea una instancia de interfaz o clase abstracta para usar directamente sus metodos sobreescritos, por ejemplo: new Interfaz( parametros ){ metodos }
    Clase objeto = new Clase(); // declara un objeto de tipo clase que utiliza un constructor, esto crea y almacena un objeto (instancia un objeto), por ejemplo: Clase nombre= new Clase( parametros );
    
    objeto.atributo; // usa un campo de clase, por ejemplo: objeto.nombreCampoDeClase;
    objeto.atributo = valor; // cambia el valor de un campo de clase, por ejemplo: objeto.nombreCampoDeClase = valor;
    objeto.metodo(); // usa un metodo, por ejemplo: objeto.nombreMetodo( parametros );
  
  
  Clases:
    package paquete.subpaquete; // declara el paquete actual de la clase, por ejemplo: package paquete.subPaquete;
    import java.util.*; // importa el paquete util procedente del paquete java junto a todas sus clases, por ejemplo: import paquete.subpaquete.*;
    import java.util.Scanner; // importa la clase Scanner del paquete util procedente del paquete java, por ejemplo: import paquete.subpaquete.Clase;
    public class Clase{} // declara una clase, por ejemplo: public class Nombre{ codigo }
      public constructor(){} // declara un constructor, por ejemplo: public nombreClase( parametros ){ codigo }
      private class Clase2{} // declara una clase interna, por ejemplo: public class nombre{private class Nombre2{ codigo }}
      public int metodo(){} // declara un metodo getter, por ejemplo: public tipo nombre( parametros ){ codigo return valor;}
      public void metodo(){} // declara un metodo setter, por ejemplo: public void nombre( parametros ){ codigo }
        class Clase3 {} // declara una clase interna local, por ejemplo: class Nombre{ codigo }
      public static void main(String args[]){} // metodo main donde empezara la ejecucion, por ejemplo: public static void main(String[] args){ codigo }
    public class Clase extends superClase{} // extiende la herencia de una clase, por ejemplo: public class Nombre extends nombreClasePadre{ codigo }
    public class Clase implements Interface{} // implementa una o mas interfaces, por ejemplo: public class Nombre implements Interfaz, Interfaz2{ codigo }
    public interface Interfaz{} // declara una interfaz, por ejemplo: public interface Nombre{ codigo } todo lo introducido sera abstracto y estatico incluyendo la interfaz y las variables se haran constantes.
    
  
  ManipulacionDeFicheros(YDirectorios):
    File fichero=new File("ruta/ruta/nombreArchivoOpcional.extension");
    fichero.exist(); // valor booleano si existe o no el archivo o directorio del constructor.
    fichero.isDirectory(); // valor booleano que indica si en el constructor se especifico un directorio o no.
    fichero.list(); // un array de strings que devuelve el nombre de cada directorio y archivo solo si la ruta que se indico en el constroctor es un directorio.
    fichero.getPath(); // devuelve la ruta actual del archivo o directorio que se indico en el constructor.
    fichero.getAbsolutePath(); // un string que muestra la ruta absoluta del fichero o directorio del archivo.
    fichero.mkdir(); // crea un nuevo directorio tomando ek cuenta la ruta.
    fichero.createNewFile(); // crea un archivo no existente con la extension de la ruta.
    fichero.delete(); // elimina un ficheto o directorio.
  
  
  ProgramacionGenerica:
    public class Clase<T>{}; // declara una clase que utiliza el argumento T el cual es una clase generica.
      private T objeto; // declara un campo de clase de tipo T el cual es una clase generica.
      public T getObject(T obj){} // declara un metodo que devuelve la clase generica y recibe la misma en sus argumentos.
      public <T> void metodo(){} // declara un metodo generico.
      
      
   Threads:
     Thread hilo=new Thread(objetoRunnable); // declara un thread, en donde el objetoRunnable es la clase qud implementa la interfaz Runnable.
     Thread.currentThread(); // eevuelve una referencia del hilo actual.
     Thread.interrupted(); // verifica si el hilo actual esta interrumpido.
     hilo.start(); // inicia la ejecucion de un thread.
     hilo.interrupt(); // interrumpe un hilo y envia una excepcion si el hilo esta bloqueado por hibernaciones de metodos como sleep o wait.
     hilo.isInterrupted(); // verifica si el hilo esta interrumpido.
     hilo.join(); // sincroniza los threads para que no se ejecute ninguno del programa hasta que este termine su ejecucion, esto abarca solo los hilos de una clase.
   
  
  Otros:
    final int CONSTANTE; // declara una constante, por ejemplo: final tipo NOMBRE;
    char variable = 'z'; // declara e inicia una variable de tipo char, por ejemplo: char  nombre = 'valor';
    byte variable = (byte) 4.56; // refunde un valor 4.56 a byte, por ejemplo: byte nombre = (casting byte) valor;
    etiqueta: while(){} // declara una etiqueta en un bucle while, por ejemplo: etiqueta: if/for/while/switch(){}
    ArrayList <Object> listaArray=new ArrayList <Object>(); // crea un objeto ArrayList generico (estos array no almacenan valores primitivos), los arrayList pueden ser interpretados por un bucle for-each.
    listaArray.trimToSize(); // libera el espacio que no este utilizando el ArrayList reduciendo su tama�o asi minimizando el uso de recursos.
    listaArray.add(objeto); // agrega un objeto.
    listaArray.set(2, objeto); // cambia lo que hay en la posicion 3 del array.
    listaArray.get(4); // devuelve el objeto en la posicion 5 del array.
    listaArray.toArray(); // devuelve un array de objetos correspondientes a la generalidad.
    listaArray.iterator(); // devuelve un objeto de la interfaz iterador para manipular un poco la lista de objetos ya sea avanzando el selector de objetos, borrando o verificando si hay un siguiente objeto para avanzar el selector.
    
================================================================================