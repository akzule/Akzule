/* @ Datos extra:
	declaración e iniciación de variable. Tipado dinámico.
	ambito de variables (alcance/scope global y local).
	funcion declarada y expresada.	
	elevación de variables y funciones (hoisting).
	objetos y datos literales e instanciados (instancias de clase, arreglos asociativos).
	encapsulamiento (privacidad).
	anidamiento.
		clausuras o cierres y sobrescritura interna a externa.
	concurrencia (multi ejecución simultánea).
	programación orientada a objetos y prototipos.
		espacios de nombre.
		metodos setter y getter.
		polimorfismo (sobre escritura).
		cadena de prototipos.
	eventos.
		escucha y controlador de evento.
		objeto event de función evento callback.
		captura y burbujeo de eventos (afuera--> adentro y viceversa).
		callback hell (el infierno de las devoluciones de llamada) o la pirámide de la perdición.
	programación asíncrona, funcional, imperativa y declarativa.
		controlador de promesas. Then y Catch.
		promesas/promises y encadenamiento de promesas.
		funciones asíncronas.
		trabajadores/workers dedicados, compartidos y de servicio.
	stream y buffer
		serializar (parsing) y decodificar (stringification).
		
	
	@ Lenguaje
	conmutador (entre estados)
	case sensitive
	modularizacion
	lenguaje interpretado y compilado
	cadenas regulares


   @ Valores false:
	false
	undefined	0 en caracteres numéricos
	null	0 en caracteres numéricos
	NaN
	0
	""


   @ Metodos Object:
	keys()
	values()
	entries()


   @ Palabras reservadas:
	length
	static
	Infinity
	
	
	@ Librería
	Number
	String
	Array
	Math
	Object
	Function
	JSON
	Fetch (Windows)
	Promise
	XMLHttpRequest
	Worker (mult thread)
*/

 
// ====================================================================================================
// @ Almacenar datos (declaración e iniciación de variables y constantes)
// los nombres aceptan $ _ letras para iniciar y luego números además de carácteres unicode
// let desactiva elevación de variables y declaración multiple de una misma variable
// se puede hacer declaración e iniciación multiple
// ====================================================================================================
let numero = 0;
let flotante = 4.67E3;	// misma sintaxis json
let gran_numero. = 9007199254740992n;
let objeto = { };
let simbolo = Symbol("llave");
let cadena = "texto";	// let o var
let booleano = true;	// false
let nulo = null;
let indefinido = undefined;
const constante = 0;


// @ Sistemas de numeración
// admiten bigNumber
let binario = 0b1011;	// ver notación: complemento binario a 2
let octal = 0o27;	// también puede iniciar con 0 sin necesidad de la "o", no recomendado 
let hexadecimal = 0x2FA8;	// admite mayúsculas y minúsculas


// @ matrices, arreglos, arrays 
let matriz = [ , , ];	// es valido dejar espacios vacios aunque dejar en último espacio vacío en algunas versiones de navegador puede dar error mientras en versiones recientes se ignora la última coma
matriz[0];

let matriz = [6, 9.45, true, "azul", [2, 3, 4]];	// matriz multidimensional)
matriz[4][1];


// @ desestructuración con valor por defecto y sintaxis extendida y valor omitido
let [variable = "defecto", , variable3] = matriz;	// los datos del array metidos en variables, también se pueden dejar espacios en blanco tras coma's
let {variable1, variable2, ...matriz} = objeto;


// @ strings
let multi_linea = "texto \
multi linea";

let multi_linea = `texto de ${ variable }
multi linea`;


// @ carácteres especiales
\0	// Byte nulo
\b	// Retroceso
\f	// Avance de Página
\n	// Nueva Línea
\r	// Retorno de carro
\t	// Tabulación
\v	// Tabulación vertical
\'	// Apóstrofo o comilla simple
\"	// Comilla doble
\\	// Caracter de barra invertida
\XXX	// El caracter con la codificación Latin-1 (0-377)
\xXX	// El caracter con la codificación Latin-1 (00-FF)
\uXXXX	// El caracter Unicode (hexadesimal)
\u{XXXXX}	// El punto de código escape Unicode (hasta 10FFFF). Ejemplo: \u{2F804} = \uD87E\uDC0



// ====================================================================================================
// @ Operadores
// ====================================================================================================
// @ Operador de concatenacion"
"Texto" + "Texto"
"Texto" + 5


// @ Operador ternario
true ? "éxito" : "fallo"


// @ Operador unitario de conversación
(+ "4") + (+ true)


// @ Operador coma
// sirve para evaluar multiples códigos en una sola sentencia
for (let i=0, let j=2; ; ){ }


// @ Operadores de incremento y decremento
variable ++
variable --
++ variable
-- variable


// @ Operadores Aritméticos
// conversión implicita de números string cuándo se opera con número normal (excepto operador +)
4 + 2	// suma
8 - 3	// resta
2 * 7	// multiplicación
2 ** 3	// potenciación
6 / 2	// división
16 % 5	// modulo (residuo)


// @ Operadores a nivel de bits y de desplazamiento
// 1 bit para signo 8 bits para exponente 23 bits para mantisa
// si se exceden los 32 bits entonces se descartan los más significativos, los de la izquierda
1 & 1	// and
1 | 0	// or
1 ^ 0	// xor
-1	// not
~0b11	// ~x = - x - 1 representación en complemento a dos
-0b1011 >> 2	// desplazamiento derecha
-0b1101 << 2	// desplazamiento izquierda
-0b1001 >>> 3	// desplazamiento derecha incluyendo bit de signo


// @ Operadores lógicos
true && true	// and, devuelve exp1 si se puede convertir a false la expresión general
true || false	// or, devuelve exp1 si se puede convertir a true la expresión general
!false	// not, devuelve false si se puede convertirse a true la expresión general


// @ Operadores de comparación
// los string se pueden comparar también
< > <= >= == === != !==	// === y !== compara identidad: valor y tipo
null ?? "valor"	// operador de coalescencia nula, devuelve el operando derecho cuándo el valor es null o undefined 


// @ Operadores de asignación
// de izquierda a derecha
// al contrario de los operadores lógicos los de asignación se evalúan de derecha a izquierda y dan un retorno del valor final asignado y el de las operaciones lógicas devuelven el valor de la evaluación
// el último operador de asignación nula hará qué el segundo operando asigne su valor al primero cuándo el primero sea null o undefined
+= -= *= /= %= **= <<= >>= >>>= &= |= ^= &&= ||= ??= 


// @ Operadores unitarios
delete objeto.color	// elimina propiedades 
typeof objeto	// devuelve el tipo de la expresión qué se entregue
void funcion();	// evalua sin devolver un valor
2 in matriz	// posición, no valor
"color" in objeto	// verifica si hay propiedades dentro de objetos
objeto instanceof Object	// verificar instancias de objetos respecto a otros


// @ Precedencia
. [ ]
( ) new
! ~ - + ++ -- typeof void delete
* / %
+ -
<< >> >>>
< <= > >= in instanceof
== != === !==
&
^
|
&&
||
?:
= += -= *= /= %= <<= >>= >>>=
,




// ====================================================================================================
// @ Condicionales y bucles
// en bucles se usa una variable inicializadora i, j, z por convención
// ====================================================================================================
etiqueta1: bloque de ejecución	// referirse a distintos flujos de ejecución iterados
break etiqueta1
continue etiqueta1

if( ){ } else{ }	// llaves opcionales
if( ){ } else if( ){ }
while( ){ }
do{ } while( )

switch (variable) {
	case 0:
		// code
		break;

	case 1:
		// code
		break;
	
	default:
		// code
		break;
}

for (let i =0; i<3; i++){ }	// inicializador o variable de contador
for (const i of matriz){ }	// recorrer arrays


// @ Recorrido de propiedades
const objeto = { color1: "rojo", color2: "azul" };
for(i in objeto){ console.log(objeto[i]) }	// recorrer propiedades de objetos




// ====================================================================================================
// @ Funciones declaradas
// lenguaje: argumento, propiedad, atributo de una función e invocar una función
// ====================================================================================================
// @ Función declarada - Tienen elevación
function funcion (arg){
	return "valor: " + arg;
}
console.log(funcion(5));


// @ Funciones expresadas: anónima y flecha
// no tienen elevación ni this, arguments, super, new.target
let funcion = function( ){ }
let funcion = condición => "devolución";	// devolución directa, única condición
let funcion = ( ) => { }	// paréntesis y/o llaves opcional


// @ Argumentos predeterminados y sintaxis rest (restantes)
function funcion (arg = "default", arg, ...argRest){
	return argRest[0];	// objeto tipo array
}
console.log(funcion(1, 6, 8, 10, 9));	// devuelve un 8


// @ Recursividad
// inicia de fuera hacía adentro e imprime de adentro hacia afuera
function funcion (arg){
	if (arg < 4){
		// code
		funcion(arg+1);
	}
}


// @ Objeto arguments
function funcion (arg){
	console.log("argumento 1 de " + arguments.length + ": " + arguments[0]);
	if (arg < 4){
		arguments.callee(arg+1);	// recursividad 
	}
	console.log("termina en: " + arg);
}


// @ Función Asíncrona
// deben siempre retornar una promesa y el await va antes de una función que retorna a una promesa (siempre dentro de una función asíncrona), estás funciones se ejecutan en secuencia.
async function funcion(){
	const promesa = await busca();
	return promesa;
}


// @ IIFE (Immediately Invoked Function Expression / Self-Executing Anonymous Function)
// paréntesis es invocación directa en cualquier función
(function funcion( ){ })( );	// 1.apropiarse de la función y 2.añadir paréntesis 




// ====================================================================================================
// @ Objetos expresados o literales
// lenguaje: propiedad / atributo
// los nombres de propiedad pueden ser números o cadenas vacías y pueden ir entre comillas si no son nombres validos
// admite el uso convencional de this, éste referente se puede almacenar en una variable!!
// ====================================================================================================
// @ Objeto expresado
const objeto = {
	variable,	// abreviatura de variable: variable
	"?": 0,
	propiedad: "azul",
	propiedad2: { prop: 100 },
	metodo: function( ){ },
	metodo2( ){ },	// forma abreviada
	["propiedad3 " + variableX]: "valor"	// propiedad dinámica
}
objeto.propiedad
objeto.metodo( );	// la variable devuelve la función y los paréntesis la ejecutan
objeto.metodo2( );	// ejecución directa
objeto["propiedad"]
objeto["propiedad2"]["prop"]	// o también objeto.propiedad2.miniprop
objeto["propiedad3 " + variableX]


// @ Objeto declarado
// nombre de función constructora en mayúscula
function Constructor1 (nombre){
	this.propiedad = nombre;
	this.metodo = function( ){ };
}
const objeto = new Constructor1("Arturo");


// @ Objeto declarado por metodo clásico de clases
// se recomienda declarar variables antes de entrar al constructor
// super clases y sub clases
class Clase {
	#nombre;	// modificador de acceso, propiedad privada y accesible sólo desde su ambito actual

	constructor (nombre) {
		this.#nombre = nombre;
	}
	metodo( ){
		console.log(this.#nombre);
	}
	#metodo2( ){
		// metodo privado
	}
}


// @ Herencia de clases
class Hijo extends Padre {
	edad;
	
	constructor (nombre, edad){
		super(nombre);	// llama al constructor padre
		this.edad = edad;
	}
}
const hijo = new Hijo("nombre", 0);




// ====================================================================================================
// @ Prototipos y constructor 
// propiedad __proto__ y metodo Object.getPrototypeOf del objeto instanciado y propiedad prototype del constructor
// en la propiedad prototype se ubica un objeto que posee todas las características heredables e incuso una propiedad constructor que apunta a la función constructora
// ====================================================================================================
// @ Prototipos
function Constructor1(){
	Objeto.prototype.color = "Azul",
	this.nombre = "mi_name"
}
let objeto = Object.create(new Constructor1());	// crea un objeto heredando el prototipo de otro objetos ya instanciado

function Constructor2(){ this.lugar = "cielo" }
objeto2 = Object.assign(objeto, new Constructor2());	// asigna propiedades de otros objetos ya instanciados (sin heredar su prototipo)
Object.getPrototypeOf(objeto)	// devuelve el objeto prototipo de un objeto 
Object.hasOwn(objeto, "color")	// verifica si una propiedad es propia y no heredada


// @ Propiedad prototype
// es recomentable establecer en el constructor los atributos al necesitar usar this para no referenciar al scope global, no sucede lo mismo con los metodos
objeto.prototype.edad = 0;	// sirve para escribir en el contenedor de herencia del prototipo
console.log("objeto base 1\n" + objeto.color + "\n" + objeto.lugar + "\n" + objeto.edad);


// @ Propiedad constructor
objeto.constructor	// devuelve al constructor del objeto (propiedad de prototype), se puede usar como constructor con new
objeto.constructor.name	// función de Function


// @  Herencia de prototipos
// __proto__
function ClaseHijo1(){
	objeto.call(this);
}
ClaseHijo1.prototype = Object.create(objProto.prototype);	// asigna un prototipo de la clase padre 
ClaseHijo1.prototype.constructor = ClaseHijo1;	// establece un constructor 
const persona1 = new ClaseHijo1();	// llama al constructor y asigna el prototipo
console.log(persona1.c);




// ====================================================================================================
// @ Errores o excepciones logicas (existen errores de sintaxis)
// los bloques try catch anidados requieren un bloque try catch o try finally
// ====================================================================================================
// @ Crear un error
function ErrorUsuario(mensaje){
  this.mensaje = mensaje;
  this.name = "error personalizado";
}

ErrorUsuario.prototype.toString = function(){
   return `${name}: ${mensaje}`;
}


// @ Atrapar un error
try {
  throw new Error("error falso")	// throw lanza un dato cualquier
  
} catch(e){	// catch lo atrapa en "e"
  console.error("error: " + e);
  
} finally{}	// se ejecuta siempre tras cada verificación y su return sustituye al de toda la estructura




// ====================================================================================================
// @ Promesas
// ====================================================================================================
// @ Implementar promesas
function busca(arg){
	return new Promise((resolve, reject) => {
		if(arg){
			resolve("sucess");	// resuelve la promesa
		}
	});
}


// @ usar promesas
busca(true).then((value) => {
	console.log("valor: " + value);
	
}).catch((error) => {
	console.log("error: " + error);
	
});
