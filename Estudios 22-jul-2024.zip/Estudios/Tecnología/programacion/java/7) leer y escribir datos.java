================================================================================
LeerYEscribirDatos:
// cada writer y reader puede causar una IOException y habre una conexion, flujo de datos o stream lo cual es lo mismo.
// un buffer o filtro es la memoria intermedio al leer o escribir datos, esto permite que cualquier cambio inesperado  en el archivo o la conexion no cause datos en la lectura o escritura de datos.
// siempre que se habra una un stream se debera cerrarse cuando termine la totalidad de su uso, normalmente con el metodo close().
// al leer un objeto se debe almacenar en una variable de ese objeto o en un array si ese objeto es un array y hacer casting.
// la clase con mas opciones con respecto a archivos y directorios es la clase File que puede hacer verificaciones, leer y escribir en archivos o crear y eliminar archivos y fichetos.

@~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  <<<Jerarquia-LecturaNormal>>>
    <Reader // leer.
      <<InputStreamReader // leer en entrada, recibe InputStream.
        <<<FileReader // leer archivos.
      <<BufferedReader // leer textos, recibe reader.
    <Writer // escribir.
      <<OutputStreamWriter //  escribir en entrada, recibe OutputStream.
        <<<FileWriter // escribir en archivos.
      <<BufferedWriter // escribir textos, recibe writer.
      
@~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  <<<Jerarquia-LecturaBytes>>>
    <InputStream // leer entrada y obtener bytes.
      <<FileInputStream // leer archivo.
      <<ObjectInputStream // leer objeto, recibe un InputStream.
    <OutputStream // escribir en salida y colocar bytes.
      <<FileOutputStream // escribir en archivo.
      <<ObjectOutputStream // escribir objeto, recibe un OutputStream.
      
@~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  EjemplosBasicos:
    FileReader fileLectura=new FileReader("ruta/ruta/archivo.extension");
      char caracter=(char)fileLectura.read();
    
    FileWrite fileEscritura=new FileWriter("ruta/ruta/archivo.extension");
      fileEscritura.write("string");
    
    BufferedReader bufferLectura=new BufferedReader(Reader tipoLeer); // en este caso el Reader varia depende de en que se use, en este caso se usaria el FileReader.
      String textoLinea=bufferLectura.readLine();
    
    BufferedWriter bufferEscritura=new BufferedWriter(Writer tipoEscribir); // en este caso el Writer varia depende de en que se use, en este caso se usaria el FileWriter.
      bufferEscritura.write("string");
      bufferEscritura.newLine();
    
@~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  EjemplosBasicosBytes:
    FileInputStream fileLectura=new FileInputStream("ruta/ruta/archivo.extension");
      int numByte=fileLectura.read();
    
    FileOutputStream fileEscritura=new FileOutputStream("ruta/ruta/archivo.extension");
      fileEscritura.write(int numByte);
    
    ObjectInputStream objetoLectura=new ObjectInputStream(new FileInputStream("ruta/ruta/archivo.extension"));
      Object tipoObjeto=(Object) objetoLectura.readObject();
  
    ObjectOutputStream objetoEscritura=new ObjectOutputStream(new FileOutputStream("ruta/ruta/archivo.extension"));
      objetoEscribir.writeObject(Object obj);
    
@~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  EjemplosClaseObjeto:
    public class Clase implements Serializable{} // declara que los objetos de una clase pueden ser escritos y leidos.
      private static final long serialVersionUID = 1; // declara el SHA en 1 de la clase y que adquiriran los objetos escrito de esta clase.

@~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  CerrarUnStream:
  objetoReader.close();
  objetoWriter.close();
  objetoInputStream.close();
  objetoOutputStream.close();
  objetoScanner.close();
  etc

================================================================================